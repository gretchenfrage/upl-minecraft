§align:center
##### §nDisenchanter§n

§stack[draconicevolution:diss_enchanter]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
With this device you are able to transfer enchantments (one at a time) from your items to books at the cost of experience.

The cost is determined by the level of each enchantment relative to the enchantment's max level. Removing an enchantment from an item also has the secondary effect of reducing the item's repair cost making it possible to re-enchant the same item as many times as you like.

To use it simply place the enchanted item in the first slot, place a regular book in the center slot and press the transfer button. The first enchantment will be stripped from the item and applied to the book.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:diss_enchanter]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}