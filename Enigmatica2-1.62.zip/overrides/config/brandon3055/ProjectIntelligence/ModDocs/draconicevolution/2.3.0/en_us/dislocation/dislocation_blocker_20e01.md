§align:center
##### §nDislocation Normalization Field Projector§n

§stack[draconicevolution:item_dislocation_inhibitor]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Does exactly what it says on the tin... well.. If you can understand the technobabble on the tin.

This is a simple device that prevents any items within 5 blocks of itself from being collected by an item dislocator. This block does not require power to run.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:item_dislocation_inhibitor]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}