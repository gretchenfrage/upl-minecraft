§align:center
##### §nDraconic Chestplate§n

§stack[draconicevolution:draconic_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Flight (Configurable)
Removes mining slowdown while in the air
Fire immunity
+200 Base Shield Capacity
+3 Armor Toughness
+8 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_chest]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}