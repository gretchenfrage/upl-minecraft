§align:center
##### §nDraconic Axe§n

§img[http://ss.brandon3055.com/a862d]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§616 Million RF capacity upgradable to 256 Million.

§63x3 base mining AOE. Upgradable to 9x9

§63 block dig depth. Upgradable to 9

§6Tree Harvesting
When enabled simply hold right click on the base of a tree and this axe will quickly block by block harvest the entire tree.
This axe can harvest up to 8192 blocks at a time. 

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_axe]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}