§align:center
##### §nDraconic §n

§img[http://ss.brandon3055.com/ff9df]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
The staff of power is one of the mods powerful items in Draconic Evolution.
It is both a mining tool and a powerful weapon with similar abilities to the Draconic Sword.
But Stronger!

§b§nStats

§648 Million RF capacity upgradeable to 768 Million.

§65x5 base mining AOE. Upgradable to 11x11

§65 block dig depth. Upgradable to 11

§660 base Attack. Upgradable to 105
It should be noted that because this is such a large heavy weapon the attack speed is fairly slow.

§65x5 base attack radius. Upgradable to 17x17
Note the AOE attack only works when the sword is fully charged.
(Referring to the new vanilla charging mechanic)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_staff_of_power]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}