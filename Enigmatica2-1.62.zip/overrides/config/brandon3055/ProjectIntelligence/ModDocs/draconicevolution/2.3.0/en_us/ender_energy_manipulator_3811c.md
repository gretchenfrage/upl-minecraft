§align:center
##### §nEnder Energy Manipulator§n

§stack[draconicevolution:ender_energy_manipulator]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Dont want to risk incurring the wrath of the Enderman by killing the Ender Dragon? 
But you still want to get your hands on a dragon egg?
No problem! 
This mystical device allows you to extract an egg from the Ender Dragon without killing her!
To get started simply craft this item and right click the end portal with it (in the end)
The process will begin immediately.
Note this may anger the enderman just a little but they will get over it. It's not like your killing the dragon after all. 

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:ender_energy_manipulator]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}