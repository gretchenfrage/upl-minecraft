§align:center
##### §nPotentiometer§n

§stack[draconicevolution:potentiometer]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
A simple redstone emitter that is capable of emitting a variable strength redstone signal between 0 and 15.

§img[http://ss.brandon3055.com/bd604]{width:100%} 
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:potentiometer]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}