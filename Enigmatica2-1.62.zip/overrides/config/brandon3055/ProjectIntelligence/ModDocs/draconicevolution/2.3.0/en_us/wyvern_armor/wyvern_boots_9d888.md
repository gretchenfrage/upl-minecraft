§align:center
##### §nWyvern Boots§n

§stack[draconicevolution:wyvern_boots]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+20 Base Shield Capacity
+2 Armor Toughness
+3 Armor
Reduced fall damage
Jump Height boost

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_boots]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}