§align:center
##### §nWyvern Helmet§n

§stack[draconicevolution:wyvern_helm]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+20 Base Shield Capacity
+2 Armor Toughness
+3 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_helm]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}