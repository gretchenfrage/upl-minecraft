§align:center
##### §nWyvern Armor§n

Wyvern armor is your first step on the journey towards the ultimate armor set!

At first glance, the armor in Draconic Evolution may seem to have fairly underwhelming stats. But the actual armor effect of this armor is NOT its primary line of defense. All armor in DE comes with a powerful §link[draconicevolution:draconic_energy_shield]{alt_text:"Draconic Energy Shield"} that is capable of absorbing massive amounts of damage.

Some pieces of the armor also provide some buffs which can, of course, be configured via the DE config GUI.

Wearing full wyvern armor gives 100% fire resistance.  

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§img[https://raw.githubusercontent.com/brandon3055/Project-Intelligence-Docs/master/Assets/Draconic%20Evolution/Armor/Wyvern%20Armor.jpg]{width:30%} 
§rule{colour:0x606060,height:3,width:100%}