§align:center
##### §nWyvern Pickaxe§n

§img[http://ss.brandon3055.com/b8090]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§64 Million RF capacity upgradable to 32 Million.

§61x1 base mining AOE. Upgradable to 5x5 

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_pick]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}