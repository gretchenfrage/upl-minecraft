See §link[enderio:dialing_device]{alt_text:"Dialing Device"}.

There is no §link[enderio:tele_pad]{alt_text:"TelePad"} in range. You can click the "Show Range" button in the top right corner to see where a TelePad must be to be usable from this Dialing Device.

Note: The Dialing Device is designed to be used when standing **on** the TelePad.