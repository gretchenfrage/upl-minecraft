§align:center
###### §nConduit Connection§n
§stack[enderio:item_item_conduit]{size:18,enable_tooltip:false}§stack[enderio:item_liquid_conduit]{size:18,enable_tooltip:false}§stack[enderio:item_power_conduit]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_conduit]{size:18,enable_tooltip:false}
§align:left

[TODO]