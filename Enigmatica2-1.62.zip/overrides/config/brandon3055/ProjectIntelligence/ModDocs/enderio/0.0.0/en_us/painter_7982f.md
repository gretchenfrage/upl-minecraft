§stack[enderio:block_painter]{size:18,enable_tooltip:false}

§recipe[enderio:block_painter]{spacing:4}