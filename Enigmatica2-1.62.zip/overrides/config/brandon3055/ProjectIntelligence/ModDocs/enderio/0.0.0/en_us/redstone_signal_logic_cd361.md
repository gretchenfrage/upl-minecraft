§align:center
###### §nRedstone Filters§n
§stack[enderio:item_material,1,60]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_not_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_or_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_and_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_nor_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_nand_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_xor_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_xnor_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_toggle_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_counting_filter]{size:18,enable_tooltip:false}§stack[enderio:item_redstone_timer_filter]{size:18,enable_tooltip:false}
§align:left

[TODO]

§4§nNote:§r These filters are for [TODO: link]Redstone Conduits.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

§recipe[enderio:item_material,1,60]{spacing:4}
§recipe[enderio:item_redstone_not_filter]{spacing:4}
§recipe[enderio:item_redstone_or_filter]{spacing:4}
§recipe[enderio:item_redstone_and_filter]{spacing:4}
§recipe[enderio:item_redstone_nor_filter]{spacing:4}
§recipe[enderio:item_redstone_nand_filter]{spacing:4}
§recipe[enderio:item_redstone_xor_filter]{spacing:4}
§recipe[enderio:item_redstone_xnor_filter]{spacing:4}
§recipe[enderio:item_redstone_toggle_filter]{spacing:4}
§recipe[enderio:item_redstone_counting_filter]{spacing:4}
§recipe[enderio:item_redstone_timer_filter]{spacing:4}
