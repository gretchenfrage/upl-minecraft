§stack[enderio:block_tank]{size:18,enable_tooltip:false}§stack[enderio:block_tank,1,1]{size:18,enable_tooltip:false}

§recipe[enderio:block_tank]{spacing:4}
§recipe[enderio:block_tank,1,1]{spacing:4}