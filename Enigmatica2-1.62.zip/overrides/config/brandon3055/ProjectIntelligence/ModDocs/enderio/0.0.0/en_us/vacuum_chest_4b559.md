§stack[enderio:block_vacuum_chest]{size:18,enable_tooltip:false}

§recipe[enderio:block_vacuum_chest]{spacing:4}