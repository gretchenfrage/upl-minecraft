§stack[enderio:block_vat]{size:18,enable_tooltip:false}§stack[enderio:block_enhanced_vat]{size:18,enable_tooltip:false}

§recipe[enderio:block_vat]{spacing:4}
§recipe[enderio:block_enhanced_vat]{spacing:4}